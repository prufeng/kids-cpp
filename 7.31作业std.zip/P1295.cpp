#include <iostream>
using namespace std;

int main() {
	int m, n;
	cin >> m >> n;
	cout << (n - m) * 30; //时钟上相邻数字之间相差30° 
	
	return 0;
}

