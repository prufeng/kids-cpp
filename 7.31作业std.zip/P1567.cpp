#include <iostream>
using namespace std;

int main() {
	int n, a, x;
	cin >> n >> a >> x;
	cout << n - x * a;
	
	return 0;
}

