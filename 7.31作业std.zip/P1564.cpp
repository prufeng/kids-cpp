#include <iostream>
using namespace std;

int main() {
	int n;
	cin >> n;
	cout << 3 * n;
	
	return 0;
}

