#include <iostream>
using namespace std;

int main() {
	int m, n, s;
	cin >> m >> n >> s;
	cout << s / n * m;
	
	return 0;
}

