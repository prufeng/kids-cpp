#include <iostream>
using namespace std;

int f(int n) {
	if(n < 1) return 0;
	return n + f(n - 3);
}

int main() {
	cout << f(100);
	
	return 0;
}

