#include <iostream>
using namespace std;

void f(int n, char a, char b, char c) {
	if(!n) return;
	f(n - 1, a, c, b);
	cout << a << " To " << c << endl;
	f(n - 1, b, a, c);
}

int main() {
	int n;
	cin >> n;
	
	f(n, 'A', 'B', 'C');
	
	return 0;
}

