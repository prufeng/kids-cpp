#include <iostream>
using namespace std;

string num = "0123456789ABCDEF";

void f(int n, int d) {
	if(!n) return;
	f(n / d, d);
	cout << num[n % d];
}

int main() {
	int n, d;
	cin >> n >> d;
	
	if(!n) cout << 0;
	else f(n, d);
	
	return 0;
}

