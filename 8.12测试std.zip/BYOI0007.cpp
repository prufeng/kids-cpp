#include <iostream>
using namespace std;

int n, q, a[1010];

int main() {
	cin >> n >> q;
	for(int i = 1; i <= n; i++)
		cin >> a[i];
		
	for(int i = 1; i <= q; i++) {
		int l, r;
		cin >> l >> r;
		int m = -1, ans = -1;
		for(int j = l; j <= r; j++) { //�����ֵ 
			if(a[j] > m) m = a[j];
		}
		for(int j = l; j <= r; j++) { //�Ҵδ�ֵ 
			if(a[j] != m && a[j] > ans) ans = a[j];
		}
		cout << ans << endl;
	}
	
	return 0;
}

