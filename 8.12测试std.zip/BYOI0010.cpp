#include <iostream>
#include <algorithm>
using namespace std;

long long n, k, a[100010], b[100010], cnt[100010], len, ans;

int main() {
	cin >> n >> k;
	for(int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	sort(a + 1, a + 1 + n);
	
	for(int i = 1; i <= n; i++) {
		if(a[i] != a[i - 1]) {
			len++;
			b[len] = a[i];
			cnt[len]++;
		}
		else {
			cnt[len]++;
		}
	}
	
	int i = 1, j = len;
	while(i <= j) {
		if(b[i] + b[j] == k) {
			if(i == j) ans += cnt[i] * (cnt[i] - 1) / 2;
			else ans += cnt[i] * cnt[j];
			i++; j--;
		}
		else if(b[i] + b[j] > k) {
			j--;
		}
		else {
			i++;
		}
	}
	
	cout << ans;
	
	return 0;
}

