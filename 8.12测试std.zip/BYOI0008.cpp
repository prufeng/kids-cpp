#include <iostream>
using namespace std;

int n, t, a[103][103], b[103][103];

int main() {
	cin >> n >> t;
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= n; j++)
			cin >> a[i][j];
	
	for(int i = 1; i <= n; i++) {
		for(int j = 1; j <= n; j++) {
			if(t == 1) b[i][j] = a[j][i];
			else b[i][j] = a[1 + n - j][1 + n - i];
		}
	}
	
	for(int i = 1; i <= n; i++) {
		for(int j = 1; j <= n; j++) {
			cout << b[i][j] << ' ';
		}
		cout << endl;
	}
	
	return 0;
}

