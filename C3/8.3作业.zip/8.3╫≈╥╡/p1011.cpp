#include <iostream>

using namespace std;

int n,sum=0;

int main()
{
	cin>>n;
	for(int i=1;i<=n;i++)
		sum+=i*i;
	cout<<sum<<endl;
	return 0;
} 
