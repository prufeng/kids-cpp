#include <iostream>
#include <climits>
using namespace std;

int n,sum=0,mx=INT_MIN,mn=INT_MAX;

int main()
{
	cin>>n;
	int x;
	for(int i=1;i<=n;i++)
	{
		cin>>x;
		sum+=x;
		mx=mx<x?x:mx;
		mn=mn>x?x:mn;
	}
	
	cout<<mx<<endl;
	cout<<mn<<endl;
	cout<<sum/n<<endl;
	return 0;
} 