#include <iostream>
#include <iomanip>
using namespace std;

int n;

double sum;

int main()
{
	cin>>n;
	int t=1;
	for(int i=1;i<=n;i++)
	{
		sum+=double(1)/i*t;
		t=-t;
	}
	cout<<fixed<<setprecision(4)<<sum<<endl;
	return 0;
} 