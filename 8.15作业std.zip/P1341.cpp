#include <iostream>
using namespace std;

int n, f[10010];

int main() {
	cin >> n;
	f[1] = 2;
	for(int i = 2; i <= n; i++)
		f[i] = f[i - 1] + 2 * (i - 1);
	cout << f[n];
	
	return 0;
}

