#include <iostream>
#include <cstdlib>
using namespace std;

int n, m, x, y, f[23][23];

bool ok(int a, int b) {
	if(a == x && b == y) return false;
	if(abs(a - x) == 1 && abs(b - y) == 2) return false;
	if(abs(a - x) == 2 && abs(b - y) == 1) return false;
	return true;
}

int main() {
	cin >> n >> m >> x >> y;
	
	if(ok(0, 0)) f[0][0] = 1;
	
	for(int i = 0; i <= n; i++) {
		for(int j = 0; j <= m; j++) {
			if(!ok(i, j)) continue;
			if(i) f[i][j] += f[i - 1][j];
			if(j) f[i][j] += f[i][j - 1];
		}
	}
	cout << f[n][m];
	
	return 0;
}

