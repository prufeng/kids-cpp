#include <iostream>
using namespace std;

int n, p, f[510];

int main() {
	cin >> n >> p;
	f[p] = 2 * p;
	for(int i = p + 1; i <= n; i++) {
		f[i] = f[i - 1] + i;
	}
	cout << f[n];
	
	return 0;
}

