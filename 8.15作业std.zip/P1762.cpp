#include <iostream>
using namespace std;

int k, f[23][23], ans;

int main() {
	cin >> k;
	for(int i = 2; i <= k; i++) {
		f[i][2] = i * (i - 1);
		for(int j = 3; j <= i; j++)
			f[i][j] = f[i - 1][j - 1] + f[i - 1][j];
	}
	
	for(int i = 1; i <= k; i++)
		ans += f[k][i];
	cout << ans;
	
	return 0;
}

