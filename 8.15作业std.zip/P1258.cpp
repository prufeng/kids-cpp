#include <iostream>
using namespace std;

int n, ans, a[103][103]; //a[i][j]��ʾ��(1,1)�ߵ�(i,j)���������� 

int main() {
	cin >> n;
	for(int i = 1; i <= n; i++) {
		for(int j = 1; j <= i; j++) {
			cin >> a[i][j];
			a[i][j] += max(a[i - 1][j - 1], a[i-1][j]);
			ans = max(ans, a[i][j]);
		}
	}
	
	cout << ans;
	
	return 0;
}

