#include <iostream>
using namespace std;
int n, a[110];
int main() {
	cin >> n;
	for(int i = 1; i <= n; i++)
		cin >> a[i];
	
	int maxi = 1; 
	int mini = 1; 
	for(int i = 2; i <= n; i++) {  
		if(a[i] > a[maxi]) maxi = i;
		if(a[i] < a[mini]) mini = i; 
	}
	
	cout << maxi << ' ' << mini;
	
	return 0;
}
