#include <iostream>
using namespace std;
int a[6][6], x, y;
int main() {
	for(int i = 1; i <= 5; i++) {
		for(int j = 1; j <= 5; j++) {
			cin >> a[i][j];
		}
	}
	cin >> x >> y;
	for(int j = 1; j <= 5; j++) {
		swap(a[x][j], a[y][j]);
	}
	for(int i = 1; i <= 5; i++) {
		for(int j = 1; j <= 5; j++) {
			cout << a[i][j] << ' ';
		}
		cout << endl;
	}
	
	return 0;
}

