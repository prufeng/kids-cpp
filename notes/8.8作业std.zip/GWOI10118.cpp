#include <iostream>
using namespace std;
int n, S, a[41][41];
int main() {
	cin >> n >> S;
	
	for(int j = 1; j <= n; j++) {
		for(int i = 1; i <= j; i++) {
			a[i][j] = S;
			S++;
			if(S == 10) {
				S = 1;
			}
		}
	}
	
	for(int i = 1; i <= n; i++) {
		for(int j = 1; j <= n; j++) {
			if(a[i][j]) cout << a[i][j];
			else cout << ' ';
		}
		cout << endl;
	}
	
	return 0;
}

