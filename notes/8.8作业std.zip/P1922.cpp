#include <iostream>
using namespace std;
int n, m, a[205][205];
int maxi = 1, maxj = 1, mini = 1, minj = 1;
int main() {
	cin >> n >> m;
	for(int i = 1; i <= n; i++) {
		for(int j = 1; j <= m; j++) {
			cin >> a[i][j];
			if(a[i][j] > a[maxi][maxj]) {
				maxi = i;
				maxj = j;
			}
			if(a[i][j] < a[mini][minj]) {
				mini = i;
				minj = j;
			}
		}
	}
	
	swap(a[maxi][maxj], a[mini][minj]);
	
	for(int i = 1; i <= n; i++) {
		for(int j = 1; j <= m; j++) {
			cout << a[i][j] << ' ';
		}
		cout << endl;
	}
	
	return 0;
}

