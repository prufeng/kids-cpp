#include <iostream>
using namespace std;
int n, a[20], cnt;
int main() {
	cin >> n;
	
	if(!n) {
		cout << 0;
		return 0;
	}
	
	while(n) {
		cnt++;
		a[cnt] = n & 1;
		n >>= 1;
	}
	
	for(int i = cnt; i >= 1; i--) {
		cout << a[i];
	}
	
	return 0;
}

