#include <iostream>
using namespace std;

int main() {
	int n;
	cin >> n;
	for(int i = 2; i <= n; i += 2) {
		for(int j = i; j <= n; j += 2) {
			int k = n - i - j;
			if(k >= j && k % 2 == 0)
				cout << i << ' ' << j << ' ' << k << endl;
		}
	}
	
	return 0;
}

