#include <iostream>
using namespace std;

int main() {
	int n, m;
	cin >> n >> m;
	
	for(int i = 0; i <= m; i++) {
		for(int j = 0; j <= m - i; j++) {
			int k = m - i - j;
			if(k % 3) continue;
			if(5 * i + 3 * j + k / 3 == n) {
				cout << i << ' ' << j << ' ' << k << endl;
			}
		}
	}
	
	return 0;
}

