#include <iostream>
using namespace std;

int main() {
	for(int i = 1; i <= 10; i++) {
		int s = 100 - 10 * i;
		if(s > 0 && s % 20 == 0)
			cout << i << ' ' << s / 20 << endl;
	}
	
	return 0;
}

