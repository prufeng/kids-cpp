#include <iostream>
using namespace std;

int main() {
	string s;
	cin >> s;
	int len = s.size() - 1;
	for(int i = 0, j = len - 1; i < j; i++, j--) {
		if(s[i] != s[j]) {
			cout << "FALSE";
			return 0;
		}
	}
	cout << "TRUE";
	
	return 0;
}

