#include <iostream>
#include <iomanip>
using namespace std;

int getMin(string s) {
	return ((s[0]-'0') * 10 + (s[1]-'0')) * 60 + (s[3]-'0') * 10 + (s[4]-'0');
}

int main() {
	string a, b;
	cin >> a >> b;
	cout << fixed << setprecision(1) << (getMin(b) - getMin(a)) * 0.5;
	
	return 0;
}

