#include <iostream>
using namespace std;
int cnt[26];
int main() {
	string s;
	cin >> s;
	for(int i = 0; i < s.size(); i++) {
		cnt[s[i] - 'a']++;
	}
	char ans = 'a';
	for(char c = 'a'; c <= 'z'; c++) {
		if(cnt[c - 'a'] >= cnt[ans - 'a'])
			ans = c;
	}
	cout << ans;
	
	return 0;
}

