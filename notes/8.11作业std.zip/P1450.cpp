#include <iostream>
#include <cmath>
using namespace std;

int main() {
	string a, b;
	cin >> a >> b;
	
	if(a.size() != b.size()) {
		cout << 1;
		return 0;
	}
	
	int n = a.size();
	bool is2 = true, is3 = true;
	for(int i = 0; i < n; i++) {
		if(a[i] != b[i]) {
			is2 = false;
			if(abs(a[i] - b[i]) != abs('A' - 'a'))
				is3 = false;
		}
	}
	
	if(is2) cout << 2;
	else if(is3) cout << 3;
	else cout << 4;
	
	return 0;
}

