#include <iostream>
#include <algorithm>
using namespace std;

struct shop {
	int cost, cnt;
} p[1010];

bool cmp(shop a, shop b) {
	return a.cost < b.cost;
}

int n, m, ans;

int main() {
	cin >> m >> n;
	for(int i = 1; i <= n; i++)
		cin >> p[i].cost >> p[i].cnt;
	
	sort(p + 1, p + 1 + n, cmp);
	
	for(int i = 1; i <= n; i++) {
		if(!m) break;
		int buy = min(m, p[i].cnt);
		ans += buy * p[i].cost;
		m -= buy;
	}
	
	cout << ans;
	
	return 0;
}

