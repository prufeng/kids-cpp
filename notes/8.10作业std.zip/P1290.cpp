#include <iostream>
#include <algorithm>
#include <iomanip>
using namespace std;

struct player {
	int id;
	double avg;
} p[105];

bool cmp(player a, player b) {
	return a.avg > b.avg;
}

int n, score[6];

int main() {
	cin >> n;
	for(int i = 1; i <= n; i++) {
		cin >> p[i].id;
		for(int j = 1; j <= 5; j++)
			cin >> score[j];
		sort(score + 1, score + 6);
		p[i].avg = (score[2] + score[3] + score[4]) / 3.0;
	}
	
	sort(p + 1, p + 1 + n, cmp);
	
	for(int i = 1; i <= 3; i++) {
		cout << p[i].id << ' ';
		cout << fixed << setprecision(3) << p[i].avg << endl;
	}
	
	return 0;
}

