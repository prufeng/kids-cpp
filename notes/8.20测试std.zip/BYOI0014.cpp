#include <iostream>
#include <algorithm>
using namespace std;
long long n, m, q, h[100010], sum[100010];

bool check(long long H) { //��Ƭ�߶�ΪHʱ�ܵõ�����ľ�� 
    int l = 1, r = n + 1;
    while(l < r) {
		int mid = l + r >> 1;
        if(h[mid] >= H) r = mid;
        else l = mid + 1;
    }
    if(l == n + 1) return false;
    return sum[n] - sum[l - 1] - (n - l + 1) * H >= m;
}

int main() {
	cin >> n >> q;
    for(int i = 1; i <= n; i++)
        cin >> h[i];
    sort(h + 1, h + 1 + n);
    for(int i = 1; i <= n; i++)
        sum[i] = sum[i - 1] + h[i];
    for(int i = 1; i <= q; i++) {
        cin >> m;
        long long l = 0, r = 2e9;
        while(l < r) {
            long long mid = l + r + 1 >> 1;
            if(check(mid)) l = mid;
            else r = mid - 1;
        }
        cout << l << endl;
    }
    
    return 0;
}

