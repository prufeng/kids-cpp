#include <iostream>
using namespace std;
int n, a[105], cnt; //ȫ�ֱ���Ĭ��Ϊ0 
int main() {
	cin >> n;
	for(int i = 1; i <= n; i++)
		cin >> a[i];
	for(int i = 1; i <= n; i++) {
		if(a[i] >= 90)
			cnt++;
	}
	cout << cnt;
	
	return 0;
}

